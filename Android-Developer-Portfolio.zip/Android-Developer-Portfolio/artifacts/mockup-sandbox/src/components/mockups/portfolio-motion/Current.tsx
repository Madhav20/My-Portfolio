import { useState } from "react";
import { ArrowDownRight, ArrowUpRight, Menu, X } from "lucide-react";
import "./_group.css";

const PROFILE = {
  name: "Madhav Maheshwari",
  initials: "MM",
};

export function Current() {
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);

  return (
    <main className="portfolio">
      <div className="grain" aria-hidden="true" />
      <header className="topbar">
        <a href="#home" className="brand" aria-label={`${PROFILE.name} home`}>
          <span className="brand-mark">{PROFILE.initials}<span>.</span></span>
          <span className="brand-caption">SOFTWARE ENGINEER II<br />ANDROID · MOBILE · WEB</span>
        </a>
        <nav className={menuOpen ? "nav-links nav-open" : "nav-links"} aria-label="Main navigation">
          <a href="#work" onClick={closeMenu}>Selected work</a>
          <a href="#experience" onClick={closeMenu}>Experience</a>
          <a href="#toolkit" onClick={closeMenu}>Toolkit</a>
          <a href="#recognition" onClick={closeMenu}>Highlights</a>
        </nav>
        <a className="nav-contact" href="#contact">Let’s talk <ArrowUpRight size={15} /></a>
        <button
          className="menu-toggle"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          aria-expanded={menuOpen}
        >
          {menuOpen ? <X /> : <Menu />}
        </button>
      </header>
      <section className="hero" id="home">
        <div className="hero-meta">
          <span className="eyebrow"><span className="live-dot" /> 5+ YEARS · SOFTWARE ENGINEER II</span>
          <span className="local-time">ANDROID · CROSS-PLATFORM · WEB</span>
        </div>
        <div className="hero-copy">
          <p className="hero-kicker">ANDROID × MOBILE PLATFORMS × WEB / BUILD TO SHIP</p>
          <h1>I build the<br /><span className="hero-outline">whole</span> <span className="hero-accent">experience.</span></h1>
          <div className="hero-bottom">
            <p className="hero-intro">Software Engineer II with 5+ years across mobile and web. I build Kotlin and Jetpack Compose Android apps, ship Flutter and .NET MAUI features, and maintain React products.</p>
            <a href="#work" className="round-link" aria-label="Explore selected work"><ArrowDownRight size={25} /></a>
          </div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="art-orbit orbit-one" />
          <div className="art-orbit orbit-two" />
          <div className="art-sun" />
          <div className="art-cross cross-a" />
          <div className="art-cross cross-b" />
          <div className="art-label label-top">ANDROID · FLUTTER · WEB</div>
          <div className="art-label label-bottom">01 — 04 / BUILDING IN CONTEXT</div>
          <div className="art-index">01<br />02<br />03</div>
          <div className="art-window">
            <div className="window-head"><span /><span /><span /><i>PRODUCT / BUILD 04</i></div>
            <div className="window-content">
              <span className="window-line short" />
              <span className="window-line" />
              <span className="window-line long" />
              <div className="window-chip">MOBILE + WEB<br /><b>IN SYNC</b></div>
            </div>
          </div>
          <div className="art-mobile">
            <div className="mobile-notch" />
            <div className="mobile-caption">BUILT FOR<br /><b>REAL LIFE.</b></div>
            <div className="mobile-tiles"><span /><span /><span /></div>
            <div className="mobile-footer"><i /><i /><i /></div>
          </div>
        </div>
        <div className="hero-rail"><span>SCROLL TO EXPLORE</span><span className="rail-line" /></div>
      </section>
    </main>
  );
}
