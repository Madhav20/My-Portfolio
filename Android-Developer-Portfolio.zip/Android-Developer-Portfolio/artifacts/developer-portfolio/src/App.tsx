import { type ReactNode, useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { ArrowDownRight, ArrowRight, ArrowUpRight, Code2, Layers3, Menu, Smartphone, X } from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

const PROFILE = {
  name: 'Madhav Maheshwari',
  initials: 'MM',
  role: 'Software Engineer II',
  email: 'madhavmaheshwarimm20@gmail.com',
  phone: '+919557265212',
  linkedin: 'https://www.linkedin.com/in/madhav-maheshwari-168736175/',
  github: 'https://github.com/Madhav20',
};

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  useEffect(() => {
    document.title = `${PROFILE.name} | Portfolio`;
    const meta = (name: string, content: string) => {
      let tag = document.querySelector(`meta[property="${name}"],meta[name="${name}"]`);
      if (!tag) { tag = document.createElement('meta'); tag.setAttribute(name.startsWith('og:') ? 'property' : 'name', name); document.head.appendChild(tag); }
      tag.setAttribute('content', content);
    };
    meta('description', `${PROFILE.name} is a Software Engineer II with 5+ years across mobile and web, specializing in Android and Kotlin with production Flutter, .NET MAUI and React experience.`);
    meta('og:title', `${PROFILE.name} | Portfolio`);
    meta('og:description', 'Android, cross-platform and React product engineering, with measurable production impact.');
    meta('og:type', 'website');
    const reveal = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) { entry.target.classList.add('is-visible'); reveal.unobserve(entry.target); }
    }), { threshold: 0.12 });
    document.querySelectorAll('.reveal').forEach((el) => reveal.observe(el));
    const onScroll = () => {
      document.documentElement.style.setProperty('--scroll-y', `${Math.min(window.scrollY * 0.12, 100)}px`);
      const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
      const progress = maxScroll > 0 ? Math.max(0, Math.min(1, window.scrollY / maxScroll)) : 0;
      document.documentElement.style.setProperty('--scroll-progress', `${progress}`);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => { reveal.disconnect(); window.removeEventListener('scroll', onScroll); };
  }, []);
  const closeMenu = () => setMenuOpen(false);
  return (
    <main className="portfolio">
      <div className="scroll-progress" aria-hidden="true"><span /></div>
      <div className="grain" aria-hidden="true" />
      <header className="topbar">
        <a href="#home" className="brand" aria-label={`${PROFILE.name} home`}><span className="brand-mark">{PROFILE.initials}<span>.</span></span><span className="brand-caption">SOFTWARE ENGINEER II<br/>ANDROID · MOBILE · WEB</span></a>
        <nav className={menuOpen ? 'nav-links nav-open' : 'nav-links'} aria-label="Main navigation">
          <a href="#work" onClick={closeMenu}>Selected work</a><a href="#experience" onClick={closeMenu}>Experience</a><a href="#toolkit" onClick={closeMenu}>Toolkit</a><a href="#recognition" onClick={closeMenu}>Highlights</a>
        </nav>
        <a className="nav-contact" href="#contact">Let’s talk <ArrowUpRight size={15}/></a>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Close menu' : 'Open menu'} aria-expanded={menuOpen}>{menuOpen ? <X/> : <Menu/>}</button>
      </header>
      <section className="hero" id="home">
        <div className="hero-meta"><span className="eyebrow"><span className="live-dot"/> 5+ YEARS · SOFTWARE ENGINEER II</span><span className="local-time">ANDROID · CROSS-PLATFORM · WEB</span></div>
        <div className="hero-copy">
          <p className="hero-kicker">ANDROID × MOBILE PLATFORMS × WEB / BUILD TO SHIP</p>
          <h1>I build the<br/><span className="hero-outline">whole</span> <span className="hero-accent">experience.</span></h1>
          <div className="hero-bottom">
            <p className="hero-intro">Software Engineer II with 5+ years across mobile and web. I build Kotlin and Jetpack Compose Android apps, ship Flutter and .NET MAUI features, and maintain React products.</p>
            <a href="#work" className="round-link" aria-label="Explore selected work"><ArrowDownRight size={25}/></a>
          </div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/>
          <div className="art-sun"/><div className="art-cross cross-a"/><div className="art-cross cross-b"/>
          <div className="art-label label-top">ANDROID · FLUTTER · WEB</div><div className="art-label label-bottom">01 — 04 / BUILDING IN CONTEXT</div>
          <div className="art-index">01<br/>02<br/>03</div>
          <div className="art-window"><div className="window-head"><span/> <span/> <span/><i>PRODUCT / BUILD 04</i></div><div className="window-content"><span className="window-line short"/><span className="window-line"/><span className="window-line long"/><div className="window-chip">MOBILE + WEB<br/><b>IN SYNC</b></div></div></div>
          <div className="art-mobile"><div className="mobile-notch"/><div className="mobile-caption">BUILT FOR<br/><b>REAL LIFE.</b></div><div className="mobile-tiles"><span/><span/><span/></div><div className="mobile-footer"><i/><i/><i/></div></div>
        </div>
        <div className="hero-rail"><span>SCROLL TO EXPLORE</span><span className="rail-line"/></div>
      </section>
      <section className="intro-band reveal">
        <div className="section-tag"><span>01</span> THE SHORT VERSION</div>
        <p className="intro-statement">Android depth.<br/><span>Mobile + web range.</span></p>
        <div className="intro-aside"><p>5+ years across mobile and web applications. Production work spans healthcare Android, Flutter, .NET MAUI, and React libraries used by nine products.</p><a href="#experience">MY EXPERIENCE <ArrowRight size={14}/></a></div>
      </section>
      <section className="work-section" id="work">
        <div className="section-heading reveal"><div><div className="section-tag"><span>02</span> SELECTED WORK / FROM MY EXPERIENCE</div><h2>Products for<br/><em>real life.</em></h2></div><p>Production learning, healthcare and cross-platform products alongside two personal Kotlin Android apps.</p></div>
        <article className="project project-feature reveal">
          <div className="project-visual visual-field"><div className="visual-orbit"/><div className="field-title">LEARN<br/><i>hub.</i></div><div className="field-small">LEARNING PLATFORM<br/>PRODUCTION RELEASES</div><div className="field-bars"><span/><span/><span/><span/><span/><span/><span/></div><div className="field-metric">4k<span> USERS</span></div><div className="field-bottom">DELOITTE LEARNHUB · PRODUCTION <ArrowUpRight size={14}/></div></div>
          <div className="project-info"><div className="project-overline">01 / PRODUCTION PLATFORM · HASHEDIN BY DELOITTE</div><h3>LearnHub</h3><p>Led delivery for Deloitte’s learning platform, serving 4,000+ users. Owned release planning, PR reviews and hotfix triage across 20+ production releases.</p><div className="impact-grid"><div><strong>20+</strong><span>production releases</span></div><div><strong>4,000+</strong><span>users served</span></div><div><strong>≈60%</strong><span>fewer release defects</span></div><div><strong>≈50%</strong><span>less authoring effort</span></div></div><div className="tag-row"><span>REACT</span><span>ASSESSMENTS</span><span>AI-ASSISTED AUTHORING</span><span>RELEASE LEADERSHIP</span></div><span className="project-note">SOFTWARE ENGINEER II · JUN 2022—PRESENT</span></div>
          <span className="project-number">01</span>
        </article>
        <article className="project project-reverse reveal">
          <div className="project-info"><div className="project-overline">02 / PRODUCTION ANDROID · US HEALTHCARE</div><h3>Healthcare<br/>Android</h3><p>Built pharmacy discovery, drug search, personalized filters and map directions for a production Android healthcare app, helping people find care and useful medication information.</p><div className="impact-grid"><div><strong>+25%</strong><span>user engagement</span></div><div><strong>+30%</strong><span>user satisfaction</span></div><div><strong>+35%</strong><span>directions usage</span></div><div><strong>+20%</strong><span>test coverage</span></div></div><div className="tag-row"><span>ANDROID</span><span>PHARMACY SEARCH</span><span>DRUG FILTERS</span><span>MAP SERVICES</span></div><span className="project-note">SOFTWARE ENGINEER I · JUL 2021—JUN 2022 · 30+ BUGS FIXED</span></div>
          <div className="project-visual visual-common"><div className="common-grid"/><div className="common-header"><span>HEALTHCARE<br/>ANDROID</span><span>SEARCH / DISCOVER</span></div><div className="common-circle">PHARMACY<br/><b>CARE.</b></div><div className="common-card card-a"><span>DRUG SEARCH</span><b>Relevant<br/>results</b><small>PERSONALIZED FILTERS</small></div><div className="common-card card-b"><span>MAP SERVICES</span><b>Directions<br/>to care</b><ArrowUpRight size={16}/></div><div className="common-footer">PRODUCTION · US HEALTHCARE</div></div><span className="project-number">02</span>
        </article>
        <article className="project project-third reveal">
          <div className="project-visual visual-atlas"><div className="atlas-top"><span>FINDBACK / ANDROID</span><span>PERSONAL PROJECT</span></div><div className="atlas-ring ring-a"/><div className="atlas-ring ring-b"/><div className="atlas-pin"><span/></div><div className="atlas-label">OFFLINE<br/><b>SCREENSHOT SEARCH</b></div><div className="atlas-coordinate">ON-DEVICE<br/>OCR + FTS4</div><div className="atlas-footer">FIND IT AGAIN, WITHOUT THE CLOUD</div></div>
          <div className="project-info"><div className="project-overline">03 / PERSONAL ANDROID PROJECT</div><h3>FindBack</h3><p>An offline screenshot organizer built with Kotlin and Jetpack Compose. On-device ML Kit OCR and Room FTS4 power typo-tolerant search with edit-distance matching.</p><div className="tag-row"><span>KOTLIN</span><span>COMPOSE · MATERIAL 3</span><span>ROOM FTS4</span><span>ML KIT OCR</span><span>PAGING 3</span><span>WORKMANAGER</span></div></div>
          <span className="project-number">03</span>
        </article>
        <article className="project project-reverse project-fourth reveal">
          <div className="project-info"><div className="project-overline">04 / PERSONAL ANDROID PROJECT</div><h3>FrameLab</h3><p>A Kotlin and Jetpack Compose video review app with synchronized side-by-side Media3 playback, manual alignment offsets and variable speed controls. Compose pointer-input and Canvas stroke annotations are saved per session in Room.</p><div className="tag-row"><span>KOTLIN</span><span>JETPACK COMPOSE</span><span>COMPOSE CANVAS</span><span>MEDIA3</span><span>ROOM</span><span>HILT · COROUTINES</span></div></div>
          <div className="project-visual visual-career" aria-hidden="true"><div className="career-top">FRAMELAB <span>PERSONAL PROJECT</span></div><div className="career-orbit"/><div className="career-title">VIDEO<br/><i>review.</i></div><div className="career-card career-card-a">PLAYBACK <b>SYNCED × 2</b></div><div className="career-card career-card-b">ANNOTATIONS <b>Saved in Room</b></div><div className="career-bottom">SIDE-BY-SIDE · ALIGNMENT · REVIEW</div></div>
          <span className="project-number">04</span>
        </article>
      </section>
      <section className="experience-section" id="experience">
        <div className="experience-intro reveal">
          <div className="section-tag"><span>03</span> WORK EXPERIENCE</div>
          <h2>Teams, craft<br/>and <em>measurable impact.</em></h2>
          <p>Production Android, learning platforms, cross-platform products and shared web interfaces.</p>
        </div>
        <div className="experience-list">
          <article className="experience-row reveal">
              <div className="experience-period">JUN 2022 — PRESENT</div>
            <div className="experience-detail">
              <div className="experience-title"><div><h3>Software Engineer II</h3><p>HashedIn by Deloitte</p></div><span>PRODUCTION</span></div>
              <ul>
                <li>Led eight engineers through 20+ production releases for Deloitte’s LearnHub platform, serving 4,000+ users; owned release planning, PR review and hotfix triage.</li>
                <li>Mentored six engineers and ran design reviews; two earned promotions or took on feature ownership. Conducted 300+ code and design reviews.</li>
                <li>Maintained shared React libraries (ui-library, pageHeader-v4 and learnhub_agent) used by nine products. Introduced analysis templates, PR checklists and root-cause tagging, reducing release defects from about 15 to 6 (≈60%).</li>
                <li>Delivered assessment features—including ACE migration, evaluation criteria, retries and bootcamp scoring—supporting 20+ assessments per month. AI question generation and quiz editing cut authoring effort by about 50%; 30 admins published 500+ questions in the first quarter.</li>
                <li>Resolved 200+ SonarQube issues and security hotspots, and remediated dependency vulnerabilities; Mend/Snyk scans reached zero critical or high findings.</li>
                <li>Built .NET MAUI screens and API integrations for a diabetes-management app with an insulin patch, supporting device communication and end-to-end workflow validation.</li>
                <li>Led a five-developer team delivering a Flutter application to production on schedule and within budget.</li>
              </ul>
            </div>
          </article>
          <article className="experience-row reveal">
            <div className="experience-period">JUL 2021 — JUN 2022</div>
            <div className="experience-detail">
              <div className="experience-title"><div><h3>Software Engineer I</h3><p>HashedIn by Deloitte</p></div><span>ANDROID</span></div>
              <ul><li>Increased engagement by 25% through pharmacy discovery and drug search in a production Android app for US healthcare.</li><li>Raised user satisfaction by 30% with advanced search filters and directions use by 35% with integrated pharmacy maps.</li><li>Fixed 30+ bugs and improved overall test coverage by 20%.</li></ul>
            </div>
          </article>
        </div>
      </section>
      <section className="approach-section" id="approach">
        <div className="approach-top reveal"><div className="section-tag"><span>04</span> HOW I CONTRIBUTE</div><p className="approach-lede">Practical solutions.<br/><i>Outcomes that matter.</i></p><span className="approach-stamp">BUILD<br/>WITH<br/><b>IMPACT.</b></span></div>
        <div className="approach-steps">
          <article className="approach-step reveal"><span className="step-num">01</span><div className="step-icon"><Layers3 size={20}/></div><div><h3>Lead delivery at scale</h3><p>Led teams of up to eight, owned release planning and shipped 20+ production releases for a learning platform used by 4,000+ people.</p></div><span className="step-aside">TEAM OF 8</span></article>
          <article className="approach-step reveal"><span className="step-num">02</span><div className="step-icon"><Smartphone size={20}/></div><div><h3>Build across mobile and web</h3><p>Delivered Android, Flutter and .NET MAUI product work while maintaining shared React libraries across nine products.</p></div><span className="step-aside">ANDROID · WEB</span></article>
          <article className="approach-step reveal"><span className="step-num">03</span><div className="step-icon"><Code2 size={20}/></div><div><h3>Make quality measurable</h3><p>Introduced team practices that cut release defects by about 60%, resolved 200+ security and quality issues, and achieved zero critical/high scan findings.</p></div><span className="step-aside">QUALITY FIRST</span></article>
        </div>
      </section>
      <section className="toolkit-section" id="toolkit">
        <div className="toolkit-head reveal"><div className="section-tag"><span>05</span> THE TOOLKIT</div><p>Mobile depth.<br/><span>Web range.</span></p></div>
        <div className="toolkit-columns">
          <div className="tool-column reveal"><div className="tool-col-head"><span>01</span><h3>Android & Kotlin</h3><span className="tool-abstract">NATIVE DEVELOPMENT</span></div><div className="tool-item"><b>Kotlin · Java</b><span>Languages</span></div><div className="tool-item"><b>Android SDK · Compose</b><span>Native UI</span></div><div className="tool-item"><b>Material 3 · Navigation</b><span>UI toolkit</span></div><div className="tool-item"><b>ViewModel · StateFlow · LiveData</b><span>State</span></div><div className="tool-item"><b>XML · View/Data Binding</b><span>Views</span></div><div className="tool-item"><b>Coil 3 · content descriptions</b><span>Images · accessibility</span></div></div>
          <div className="tool-column reveal"><div className="tool-col-head"><span>02</span><h3>Architecture & Data</h3><span className="tool-abstract">APP FOUNDATIONS</span></div><div className="tool-item"><b>MVVM · Hilt · Dagger</b><span>Architecture · DI</span></div><div className="tool-item"><b>Coroutines · Flow · BLoC</b><span>Async</span></div><div className="tool-item"><b>Room FTS4 · Paging 3</b><span>Local data</span></div><div className="tool-item"><b>WorkManager · Retrofit</b><span>Background · network</span></div><div className="tool-item"><b>Media3 · ML Kit OCR</b><span>Media · on-device ML</span></div><div className="tool-item"><b>REST · GraphQL</b><span>APIs</span></div></div>
          <div className="tool-column tool-column-last reveal"><div className="tool-col-head"><span>03</span><h3>Cross-platform & Quality</h3><span className="tool-abstract">WEB · DELIVERY · TESTING</span></div><div className="tool-item"><b>Flutter · .NET MAUI · React</b><span>Mobile · web</span></div><div className="tool-item"><b>Dart · C# · SQL</b><span>Languages</span></div><div className="tool-item"><b>JUnit · Mockito · MockK</b><span>Testing</span></div><div className="tool-item"><b>AndroidJUnitRunner · MigrationTestHelper</b><span>Instrumented tests</span></div><div className="tool-item"><b>Gradle KTS · catalogs · KSP</b><span>Build</span></div><div className="tool-item"><b>Git · Android Studio</b><span>Tools</span></div></div>
        </div>
      </section>
      <section className="recognition-section" id="recognition">
        <div className="recognition-heading reveal"><div className="section-tag"><span>06</span> RECOGNITION & EDUCATION</div><h2>Milestones earned.<br/><em>Foundations built.</em></h2></div>
        <div className="recognition-grid">
          <div className="recognition-panel reveal"><div className="recognition-label">AWARDS</div><ul className="award-list"><li><span>APR 2026</span><strong>Spot Award</strong></li><li><span>APR 2025</span><strong>Spot Award</strong></li><li><span>JUN 2023</span><strong>Excellence Award</strong></li><li><span>JUN 2022</span><strong>Rising Star Spot Award</strong></li><li><span>APR 2022</span><strong>Client Award</strong></li></ul></div>
          <div className="recognition-panel education-panel reveal"><div className="recognition-label">EDUCATION</div><div className="education-item"><span>AUG 2017 — JUL 2021</span><h3>Bachelor of Technology</h3><p>Information Technology · ABES Engineering College</p></div></div>
        </div>
        <div className="competition-strip reveal"><div><strong>AIR 1045</strong><span>TCS CodeVita 2021 · 200,000+ participants</span></div><div><strong>500+</strong><span>programming problems solved</span></div><div><strong>50+</strong><span>Android articles · GeeksforGeeks</span></div></div>
      </section>
      <section className="contact-section" id="contact">
        <div className="contact-top"><div className="section-tag"><span>07</span> GET IN TOUCH</div><span className="contact-side">ANDROID · FLUTTER · WEB</span></div>
        <h2>Have a good<br/>problem to <em>solve?</em></h2>
        <div className="contact-bottom"><p>For roles, collaborations or a conversation about building useful mobile and web products, get in touch.</p><a className="contact-button" href={`mailto:${PROFILE.email}?subject=Hello%20Madhav`}>EMAIL MADHAV <ArrowUpRight size={18}/></a></div>
        <div className="contact-watermark">LET’S<br/>MAKE IT<br/><i>REAL.</i></div>
      </section>
      <footer className="footer"><a href="#home" className="footer-brand">{PROFILE.initials}<span>.</span></a><span>SOFTWARE ENGINEER II · ANDROID · MOBILE · WEB</span><div><a href={`mailto:${PROFILE.email}`}>EMAIL <ArrowUpRight size={12}/></a><a href={`tel:${PROFILE.phone}`}>PHONE <ArrowUpRight size={12}/></a><a href={PROFILE.linkedin} target="_blank" rel="noreferrer">LINKEDIN <ArrowUpRight size={12}/></a><a href={PROFILE.github} target="_blank" rel="noreferrer">GITHUB <ArrowUpRight size={12}/></a></div><span className="footer-copy">© {new Date().getFullYear()} {PROFILE.name.toUpperCase()}</span></footer>
    </main>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
